public class UserMissile extends Missile{

}
