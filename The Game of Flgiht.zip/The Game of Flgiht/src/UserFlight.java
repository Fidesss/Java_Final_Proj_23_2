import javax.imageio.IIOException;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class UserFlight extends Model {

    public UserFlight() {
        this.x = 250;
        this.y = 600;
        this.width = 0;
        this.height = 0;

        try {
            this.img = ImageIO.read(new File("UserFlight.png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
