import javax.swing.*;

public class FlightFrame extends JFrame {
    Model model;
    Controller controller;
    FlightFrame(){
        setSize(600,800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("갤러그 게임");
        add(new FlightView());
        setVisible(true);
    }
}
