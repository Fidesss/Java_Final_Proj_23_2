import java.awt.*;
import java.awt.image.BufferedImage;

public abstract class Model {
    //Data Base
    int x;
    int y;
    int width;
    int height;
    BufferedImage img;

    UserFlight userFlight;
    //    Missile missile;
//    Enemy enemy;

//    int speed;
//    int HP;
//    Toolkit toolkit = Toolkit.getDefaultToolkit(); //Toolkit
}
