import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Controller extends KeyAdapter implements Runnable {
    boolean KeyUp;
    boolean KeyDown;
    boolean KeyRight;
    boolean KeyLeft;
    int count = 0;

    UserFlight userFlight;
    FlightView flightView;


    public Controller(UserFlight userFlight, FlightView flightView) {
        this.userFlight = userFlight;
        this.flightView = flightView;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int keycode = e.getKeyCode();
        switch (keycode) {
            case KeyEvent.VK_UP -> {
                KeyUp = true;
                break;
            }
            case KeyEvent.VK_DOWN -> {
                KeyDown = true;
                break;
            }
            case KeyEvent.VK_RIGHT -> {
                KeyRight = true;
                break;
            }
            case KeyEvent.VK_LEFT -> {
                KeyLeft = true;
                break;
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int keycode = e.getKeyCode();
        switch (keycode) {
            case KeyEvent.VK_UP -> {
                KeyUp = false;
                break;
            }
            case KeyEvent.VK_DOWN -> {
                KeyDown = false;
                break;
            }
            case KeyEvent.VK_RIGHT -> {
                KeyRight = false;
                break;
            }
            case KeyEvent.VK_LEFT -> {
                KeyLeft = false;
                break;
            }
        }
    }

    public void KeyMove() {
        if (this.KeyUp) this.userFlight.y -= 5;
        if (this.KeyDown) this.userFlight.y += 5;
        if (this.KeyRight) this.userFlight.x += 5;
        if (this.KeyLeft) this.userFlight.x -= 5;
    }

    public void run() {
        try {
            while (true) {
                KeyMove();
                this.flightView.repaint();
                Thread.sleep(50);
            }
        } catch (Exception e) {
        }

    }
}
