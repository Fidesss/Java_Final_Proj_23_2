public class Missile extends Model{

}
