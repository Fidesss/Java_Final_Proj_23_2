public class Enemy extends Model{
    int HP;
    public Enemy(int x, int y) {

    }
}
