import javax.swing.*;
import java.awt.*;

public class FlightView extends JPanel {
    Image bufferImg; // 버퍼링 도화지
    Graphics buffG; // 버퍼링 붓
    UserFlight userFlight;
    Enemy enemy;
    Missile missile;
    Model model;
    Controller controller;

    public FlightView() {
        //객체 생성
        userFlight = new UserFlight();
        controller = new Controller(userFlight, this);

        // 키 이벤트 처리
        addKeyListener(controller);

        //스레드 생성
        Thread th = new Thread(controller);
        th.start();
    }
    @Override
    public void paintComponent(Graphics g) {
//        bufferImg = createImage(getWidth(), getHeight());// 이미지 클래스 버퍼링-> 도화지
//        buffG = bufferImg.getGraphics(); //그래픽스 클래스 -> 붓 -- 더블버퍼링을 구현한 것
//        update(g);
        drawUserFlight(g); //여기까지는 잘 그려짐
    }
    @Override
    public void update(Graphics g) {
//        buffG.clearRect(0, 0, 600, 800);
    }
    public void drawUserFlight(Graphics g){
        g.drawImage(userFlight.img,userFlight.x,userFlight.y,this);
    }

}