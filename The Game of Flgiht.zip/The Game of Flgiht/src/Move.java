public interface Move {
    void move();
}
