public class EnemyMissile extends Missile{

}
