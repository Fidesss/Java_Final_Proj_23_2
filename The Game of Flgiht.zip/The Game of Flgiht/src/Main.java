public class Main {
    public static void main(String[] args) {
        FlightFrame f = new FlightFrame();
    }
}