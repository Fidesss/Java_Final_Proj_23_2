package Game_Class;

public class MyThread extends Thread {
    private Flight flight;
    private Missile misile;
    private Enemy enemy;
    private Ingame_Panel GamePanel;
    public MyThread(Ingame_Panel p, Flight f, Missile m, Enemy e){
        this.GamePanel = p;
        this.flight = f;
        this.misile = m;
        this.enemy = e;
    }
    public void run() {
        while (true) {
            flight.update(); // update를 하고 repaint즉 다시 그려주어야 계속해서 그림이 업데이트 되는것.
            enemy.update();
            misile.update();
            GamePanel.drawPanel();
             // repaint는 draw 메소드를 부르고 draw메소드가 jvm에게 신호를보내고 jvm이 paintcomponenet를 실행
            try {
                Thread.sleep(5);
            } catch (InterruptedException e) {
            }
        }
    }
}
