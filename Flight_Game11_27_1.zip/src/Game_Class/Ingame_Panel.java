package Game_Class;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JPanel;

public class Ingame_Panel extends JPanel implements KeyListener {
    private Flight flight;
    private Enemy enemy;
    private Missile misile;
    Ingame_Panel() {
        super(); //이거 super왜부르는거지?
        this.addKeyListener(this);
        this.requestFocus(); // 이미지를 보여주기 위한 코드
        setFocusable(true);

        flight = new Flight();
        enemy = new Enemy();
        misile = new Missile();
        MyThread mythread = new MyThread(this,flight,misile,enemy);
        mythread.start();
    }


    public void keyPressed(KeyEvent event) {
        flight.keyPressed(event);
        misile.keyPressed(event, flight.f_x, flight.f_y);
    }

    public void keyReleased(KeyEvent event) {
    }

    public void keyTyped(KeyEvent event) {
    }

    public void paint(Graphics g) {
        super.paint(g);
        flight.draw(g);
        enemy.draw(g);
        misile.draw(g);

    }

    public void drawPanel(){
        repaint();
    }
//    public void paintComponent(Graphics g) {
//        super.paintComponent(g);
//        g.drawImage(flight.img, flight.f_x, flight.f_y, null);
//    }
}
