package Game_Class;

public class Main {

    public static void main(String[] args) {
        Game_Frame frame = new Game_Frame();
    }
}
