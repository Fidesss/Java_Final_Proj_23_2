package Game_Class;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class Missile {
    ArrayList msArr;
    private boolean launched = true;
    BufferedImage img = null;


    private int m_x = 300;
    private int m_y = 500;


    public Missile() {
//        try {
//            img = ImageIO.read(new File("Re_misile_img.png"));
//        } catch (IOException var3) {
//            System.out.println("no image");
//            System.exit(0);
//        }
        msArr = new ArrayList();
    }


    public void update() {
        if (launched)
            m_y -= 1;
        if (m_y < 0)
            launched = false;
    }


    public void keyPressed(KeyEvent e, int x, int y) {
        int keycode = e.getKeyCode();
        if (keycode == KeyEvent.VK_SPACE) {
            launched = true;
            this.m_x = x;
            this.m_y = y;

        }
    }
    public void keyReleased(KeyEvent e){
        int keycode = e.getKeyCode();
        if(keycode == KeyEvent.VK_SPACE){
            launched = false;
        }
    }

    public void draw(Graphics g) {
        g.drawImage(img, m_x, m_y, null);
    }

}

