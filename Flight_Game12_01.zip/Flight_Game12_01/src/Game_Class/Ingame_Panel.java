package Game_Class;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.swing.JPanel;

public class Ingame_Panel extends JPanel implements KeyListener {
    File file;

    private boolean keyspace = false;
    private Flight flight;
    private Enemy enemy;
    private Missile misile;
    Ingame_Panel() {
        super();
        this.addKeyListener(this);
        this.requestFocus(); // 이미지를 보여주기 위한 코드
        setFocusable(true);

        flight = new Flight();
        enemy = new Enemy();
        misile = new Missile();
        MyThread mythread = new MyThread(this,flight,misile,enemy);
        mythread.start();
    }


    public void keyPressed(KeyEvent event) {
        flight.keyPressed(event);
        misile.keyPressed(event, flight.f_x, flight.f_y);
        if(event.getKeyCode() == KeyEvent.VK_SPACE){
            keyspace = true;
        }

    }

    public void keyReleased(KeyEvent event) {
        flight.keyReleased(event);
    }

    public void keyTyped(KeyEvent event) {
    }

    public void paint(Graphics g) {
        super.paint(g); 
        // 여기서 draw메소드는 현재 좌표에서 이미지를 찍어주는 역할
        flight.draw(g);
        enemy.draw(g);
        misile.draw(g);

    }
    public void update(Graphics g){

    }
    public void Ms_Process() {

    }

    public void drawPanel(){
        repaint();
    }

}
