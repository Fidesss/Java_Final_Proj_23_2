package Game_Class;

import java.awt.*;

public class MyThread extends Thread {
    private Flight flight;
    private Missile missile;
    private Enemy enemy;
    private Ingame_Panel GamePanel;
    public MyThread(Ingame_Panel p, Flight f, Enemy e){
        this.GamePanel = p;
        this.flight = f;
        this.enemy = e;
    }
    public void run() {
        while (true) {
            //update메소드 현재 객체의 좌표를 바꿔주는 역할을 한다.
            enemy.update();
            flight.Keyprocess(); // boolean값으로 방향키를 체크해서 좌표값을 바꿔주는 메소드
            GamePanel.drawPanel(); // repaint
            try {
                Thread.sleep(20);
            } catch (InterruptedException e) {
            }
        }
    }
}
