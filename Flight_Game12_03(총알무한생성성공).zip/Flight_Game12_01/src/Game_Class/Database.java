package Game_Class;

import Game_Class.Enemy;
import Game_Class.Missile;

import java.util.ArrayList;
import java.util.Map;

public class Database {
        Missile m;
        Enemy e;
        ArrayList<Missile> Marr;
        ArrayList<Enemy> Earr;
    Database(){
        Marr = new ArrayList<Missile>();
        Earr = new ArrayList<Enemy>();
    }
    
    //적 생성을 arraylist로 생성
//    public void EAddArr(){
//        Earr.add(new Enemy())
//    }

}
