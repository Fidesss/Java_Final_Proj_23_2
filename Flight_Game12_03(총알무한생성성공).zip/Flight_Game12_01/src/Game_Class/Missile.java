package Game_Class;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class Missile {
    ImageIcon img;
    int m_x;
    int m_y;
    int MSpeed = 2;


    public Missile(int x, int y) {
        this.m_x = x;
        this.m_y = y;
        img = new ImageIcon("Re_misile_img.png");
    }

    public void move() { // update가 move로 바뀜
        m_y -= MSpeed;
    }

}

