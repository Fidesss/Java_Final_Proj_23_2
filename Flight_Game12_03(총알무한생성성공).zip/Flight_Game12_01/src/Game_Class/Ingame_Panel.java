package Game_Class;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.lang.reflect.Array;
import java.util.ArrayList;
import javax.swing.JPanel;

public class Ingame_Panel extends JPanel implements KeyListener {
    Image buffImage;
    Graphics buffG;
    //DB생성
    ArrayList<Missile> Marr = new ArrayList<Missile>();
    ArrayList<Enemy> Earr = new ArrayList<Enemy>();
    private Flight flight;
    private Enemy enemy;
    Missile ms;

    Ingame_Panel() {
        super();
        this.addKeyListener(this);
        // 이미지를 보여주기 위한 코드
        this.requestFocus();
        setFocusable(true);

        // draw메소드가 실행되어야 이미지가 보여짐
        flight = new Flight(this);
        enemy = new Enemy();
//        missile = new Missile();

        // Arraylist 생성
        MyThread mythread = new MyThread(this, flight, enemy);
        mythread.start();
    }

    @Override
    public void keyPressed(KeyEvent event) {
        flight.keyPressed(event);
    }

    @Override
    public void keyReleased(KeyEvent event) {
        flight.keyReleased(event);
//        missile.keyReleased(event);
    }

    @Override
    public void keyTyped(KeyEvent event) {
    }

// paint component를 사용하고 paint 메소드를 주석처리했더니 갑자기 잔상이 사라짐 아 paintComponent default값을 못불러와서 이렇게된걸까?

    @Override
    public void paintComponent(Graphics g) { // 여기에다가 그림 그릴 메소드를 제정의하는것이 좋다.
        repaint();
        super.paintComponent(g);
        buffImage = createImage(getWidth(), getHeight()); // jcomponent의 메소드
        buffG = buffImage.getGraphics();
        flight.draw(g);
        enemy.draw(g);
        update(g);

    }

    public void update(Graphics g) {
        drawUserMissile(g);
    }

    public void drawPanel() {
        repaint();
    }

    public void drawUserMissile(Graphics g) { // 지금 문제점은 반복이 되지 않음
        for (int i = 0; i < Marr.size(); i++) {
            ms = Marr.get(i);
            g.drawImage(ms.img.getImage(), ms.m_x, ms.m_y, this);
            ms.move();
            if (ms.m_y < 0)
                Marr.remove(i);
        }
    }

}
