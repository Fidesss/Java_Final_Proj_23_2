package Game_Class;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Enemy {
    ImageIcon img;

    int ad_s = 5;
    int e_x = 0;
    int e_y = 0;

    public Enemy() {
        img = new ImageIcon("Re_enemy_img.png");
    }
    public void update() {
        e_y += ad_s;
        if (e_y < 0)
            ad_s = 5; //이렇게 좌표를뿌려주면서 프레임을 벗어나지않고이동
        if (e_y > 600)
            ad_s = -5;
    }

    public void draw(Graphics g) {
        g.drawImage(img.getImage(), e_x, e_y, null);
    }
}
