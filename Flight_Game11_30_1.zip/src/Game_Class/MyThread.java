package Game_Class;

public class MyThread extends Thread {
    private Flight flight;
    private Missile misile;
    private Enemy enemy;
    private Ingame_Panel GamePanel;
    public MyThread(Ingame_Panel p, Flight f, Missile m, Enemy e){
        this.GamePanel = p;
        this.flight = f;
        this.misile = m;
        this.enemy = e;
    }
    public void run() {
        while (true) {
            //update메소드 현재 객체의 좌표를 바꿔주는 역할을 한다.
            flight.update();
            enemy.update();
            misile.update();
            GamePanel.drawPanel();
            flight.F_Keyprocess();
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
            }
        }
    }
}
