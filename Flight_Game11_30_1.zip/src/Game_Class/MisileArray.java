package Game_Class;

import java.util.ArrayList;

public class MisileArray{
    Missile m;
    ArrayList<Missile> misileCount = new ArrayList<Missile>(10);
    public  MisileArray(){
    }
}
