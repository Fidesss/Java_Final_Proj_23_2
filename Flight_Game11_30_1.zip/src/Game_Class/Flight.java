//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package Game_Class;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Flight {
    private boolean UpKey = false;
    private boolean DownKey = false;
    private boolean RightKey = false;
    private boolean LeftKey = false;
    private boolean space = false;
    BufferedImage img = null;
    int f_x = 250; //비행기의 x좌표
    int f_y = 600; //비행기의 y좌표

    public Flight() {
        try {
            img = ImageIO.read(new File("ReSize_Flight_img.png"));
        } catch (IOException var3) {
            System.out.println("no image");
            System.exit(0);
        }
    }

    public void keyPressed(KeyEvent e) {
        int keycode01 = e.getKeyCode();
        switch (keycode01) {
            case KeyEvent.VK_UP -> {
                UpKey = true;

                break;
            }
            case KeyEvent.VK_DOWN -> {
                DownKey = true;

                break;
            }
            case KeyEvent.VK_LEFT -> {
                LeftKey = true;

                break;
            }
            case KeyEvent.VK_RIGHT -> {
                RightKey = true;

                break;
            }
        }
    }

    public void keyReleased(KeyEvent e) {
        int keycode02 = e.getKeyCode();
        switch (keycode02) {
            case KeyEvent.VK_UP -> {
                UpKey = false;

                break;
            }
            case KeyEvent.VK_DOWN -> {
                DownKey = false;

                break;
            }
            case KeyEvent.VK_LEFT -> {
                LeftKey = true;

                break;
            }
            case KeyEvent.VK_RIGHT -> {
                RightKey = false;

                break;
            }
        }
    }


//    public void paintComponent(Graphics g) {
//        super.paintComponent(g);
//        g.drawImage(img, this.f_x, this.f_y, null);
//    }

    public void update() {
    }

    public void F_Keyprocess() {
        if (UpKey) f_y -= 5;
        if (DownKey) f_y += 5;
        if (RightKey) f_x += 5;
        if (LeftKey) f_x -= 5;

    }

    public void draw(Graphics g) {
        g.drawImage(img, f_x, f_y, null);
    }
}

