package Game_Class;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Enemy {
    BufferedImage img = null;

    int ad_s = 10;
    int e_x = 0;
    int e_y = 0;

    public Enemy() {
        try {
            img = ImageIO.read(new File("Re_enemy_img.png"));
        } catch (IOException var3) {
            System.out.println("no image");
            System.exit(0);
        }
    }


    public void update() {
        e_x += ad_s;
        if (e_x < 0)
            ad_s = 10; //이렇게 좌표를뿌려주면서 프레임을 벗어나지않고이동
        if (e_x > 500)
            ad_s = -10;
    }

    public void draw(Graphics g) {
        g.drawImage(img, e_x, e_y, null);
    }
}
