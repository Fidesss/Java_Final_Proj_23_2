package Game_Class;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class Ingame_Panel extends JPanel implements KeyListener {
    Toolkit tk = Toolkit.getDefaultToolkit();
    BufferedImage img = null;
    Image Misile_img;
    Image buffImage;
    Graphics buffImg;
    public static boolean keyspace = false;
    private ArrayList Ms_List;
    private Flight flight;
    private Enemy enemy;
    private Missile misile;

    Ingame_Panel() {
        super();
        this.addKeyListener(this);
        this.requestFocus(); // 이미지를 보여주기 위한 코드
        setFocusable(true);

        flight = new Flight();
        enemy = new Enemy();
        misile = new Missile();
        init();
        Ms_List = new ArrayList();
        MyThread mythread = new MyThread(this, flight, misile, enemy);
        mythread.start();
    }

    @Override
    public void keyPressed(KeyEvent event) {
        flight.keyPressed(event);
        misile.keyPressed(event, flight.f_x, flight.f_y);
    }

    @Override
    public void keyReleased(KeyEvent event) {
        flight.keyReleased(event);
        misile.keyReleased(event);
    }

    @Override
    public void keyTyped(KeyEvent event) {
    }
    public void init(){
        try {
            Misile_img = ImageIO.read(new File("Re_misile_img.png"));
        } catch (IOException var3) {
            System.out.println("no image");
            System.exit(0);
        }
    }

    public void paint(Graphics g) { // 여기서 draw메소드는 현재 좌표에서 이미지를 찍어주는 역할
        super.paint(g);
        buffImage = createImage(600,800);
        buffImg = buffImage.getGraphics();

        flight.draw(g);
        enemy.draw(g);
        update(g);
    }

    public void update(Graphics g) {
        Draw_Misile();
    }

    public void drawPanel() {
        repaint();
    }

    public void Draw_Misile() {
        for (int i = 0; i < Ms_List.size(); i++) {
            misile = (Missile) (Ms_List.get(i)); // i에 해당하는 인덱스의 있는 요소를 return
            buffImg.drawImage(Misile_img, misile.pos.x, misile.pos.y,this);
            misile.move();
        }
    }

    public void Misile_Process() {
        if (keyspace) {
            misile = new Missile(flight.f_x, flight.f_y);
            Ms_List.add(misile);
        }
    }
}
