package Game_Class;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Missile {
    BufferedImage img = null;
    ImageIcon icon;
    Image image;
    private int m_x = 300;
    private int m_y = 500;
    Point pos;


    public Missile(){

    }
    public Missile(int x, int y) {
        this.m_x = x;
        this.m_y = y;
        pos = new Point(m_x,m_y);

    }


    public void update() { // 위치가 변하는 것을 넣은 메소드
            m_y -= 10;
    }


    public void keyPressed(KeyEvent e, int x, int y) {
        int keycode = e.getKeyCode();
        if (keycode == KeyEvent.VK_SPACE) {
            Ingame_Panel.keyspace = true;
            this.m_x = x;
            this.m_y = y;

        }
    }

    public void keyReleased(KeyEvent e) {
        int keycode = e.getKeyCode();
        if (keycode == KeyEvent.VK_SPACE) {
            Ingame_Panel.keyspace = false;
        }
    }

    public void draw(Graphics g) { //위치에 그려주는 메소드
        g.drawImage(img, m_x, m_y, null); // null이었던 이유는 여기서 안그리기 때문
    }

    public void move() {
        pos.y -= 10;
    }

    public BufferedImage Image_ms() {
        try {
            img = ImageIO.read(new File("Re_misile_img.png"));
        } catch (IOException var3) {
            System.out.println("no image");
            System.exit(0);
        }
        return img;
    }

}

