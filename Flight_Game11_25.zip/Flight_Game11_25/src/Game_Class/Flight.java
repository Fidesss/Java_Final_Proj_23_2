//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package Game_Class;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Flight {
    BufferedImage img = null;
    int f_x = 250; //비행기의 x좌표
    int f_y = 600; //비행기의 y좌표

    public Flight() {
        try {
            img = ImageIO.read(new File("ReSize_Flight_img.png"));
        } catch (IOException var3) {
            System.out.println("no image");
            System.exit(0);
        }
    }

    public void keyPressed(KeyEvent e) {
        int keycode = e.getKeyCode();
        switch (keycode) {
            case KeyEvent.VK_UP -> {
                f_y -= 10;
                break;
            }
            case KeyEvent.VK_DOWN -> {
                f_y += 10;
                break;
            }
            case KeyEvent.VK_LEFT -> {
                f_x -= 10;
                break;
            }
            case KeyEvent.VK_RIGHT -> {
                f_x += 10;
                break;
            }
        }
    }


//    public void paintComponent(Graphics g) {
//        super.paintComponent(g);
//        g.drawImage(img, this.f_x, this.f_y, null);
//    }

    public void update() {
    }

    public void draw(Graphics g) {
        g.drawImage(img, f_x, f_y, null);
    }
}

