package Game_Class;

import java.awt.*;
import java.awt.event.KeyListener;

public class MyRunnable extends Ingame_Panel implements Runnable {
//    Flight flight01;
    Missile misile01;
    Enemy enemy01;
    public void run() {
        while (true) {
//            flight01.update(); // update를 하고 repaint즉 다시 그려주어야 계속해서 그림이 업데이트 되는것.
            enemy01.update();
            misile01.update();
            repaint();
             // repaint는 draw 메소드를 부르고 draw메소드가 jvm에게 신호를보내고 jvm이 paintcomponenet를 실행
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
            }
        }
    }
}
