package Game_Class;

public class Bomb {
    public Bomb() {
    }
}
